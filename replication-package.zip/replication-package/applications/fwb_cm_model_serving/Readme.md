Average of init_before is : 4499.294329896907
Average of init_after is : 3662.721649484536
Percent difference is : -18.593419747037068
Average of e2e_before is : 7584.440412371134
Average of e2e_after is : 6884.325463917527
Percent difference is : -9.230937424356787
Average of Max Memory used before is : 298.5360824742268
Average of Max Memory used after is : 273.1855670103093
Percent difference is : -8.491608536501142

## 500 Cold Starts CDF
## Initialization:
![](init.png)

## Execution:
![](exec.png)

## End-to-end:
![](e2e.png)