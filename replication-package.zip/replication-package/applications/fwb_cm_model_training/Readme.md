Average of init_before is : 4609.618775510204
Average of init_after is : 3806.1494845360826
Percent difference is : -17.430276343951917
Average of e2e_before is : 9278.795204081633
Average of e2e_after is : 8478.054432989691
Percent difference is : -8.629792483615816
Average of Max Memory used before is : 289.0408163265306
Average of Max Memory used after is : 268.3298969072165
Percent difference is : -7.165396113439182

## 500 Cold Starts CDF
## Initialization:
![](init.png)

## Execution:
![](exec.png)

## End-to-end:
![](e2e.png)