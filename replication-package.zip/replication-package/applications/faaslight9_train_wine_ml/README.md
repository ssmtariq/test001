- Application Name: FaaSLight 9

Optimization: Removed the use of Pandas

```
faaslight9_train_wine_ml
597
522
Average of exec_before is : 1378.705108877722
Average of exec_after is : 1460.176704980843
Percent difference is : 5.909283687897513
Average of init_before is : 4822.463735343383
Average of init_after is : 2687.503678160919
Percent difference is : -44.27114799299666
Average of e2e_before is : 6201.168844221105
Average of e2e_after is : 4147.680383141763
Percent difference is : -33.11453876946113
Average of Max Memory used before is : 252.0787269681742
Average of Max Memory used after is : 188.56513409961687
Percent difference is : -25.19593526691213
```


## 100+ Cold Starts
## Initialization:
![](init.png)

## Execution:
![](exec.png)

## End-to-end:
![](e2e.png)
